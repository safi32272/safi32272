﻿using UnityEngine;
using System.Collections;

// Doesn't do anything yet
public class AIZombieStateMachine : AIStateMachine
{

}
